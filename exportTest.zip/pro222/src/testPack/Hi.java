/* 여러줄
   주석문
 */   
package testPack;

public class Hi {

	public static void main(String[] args) {
		// 한줄주석문. 코드에 영향을 주지 않는다
		System.out.println("test 1234 ^-^");
		System.out.println("두번째 줄");
		System.out.println("");	//빈줄. 단순 줄바꿈
		System.out.println(" ");//공백1칸 출력
		System.out.println("333");
	}

}

