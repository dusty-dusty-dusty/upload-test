package ch02;

public class Ex01_p43 {

	public static void main(String[] args) {
		System.out.println(true);//boolean. 논리형
		System.out.println(false);//boolean
		System.out.println('a'); //character.1글자 ''감싸야한다
		System.out.println("a"); //문자열(String.1글자 이상의 문자)
		System.out.println(3.14);//숫자-실수
		System.out.println(100); //숫자-정수
		
		System.out.println("-------------------"); //
		System.out.println("김영재"); //문자열(String.1글자 이상의 문자) ""감싸야한다
		System.out.println("님, 환영");
		System.out.print("현빈");
		System.out.println("님, 환영");
		
	}

}
