package ch05;

public class Tire01 {
	
	//field-데이터
	//[접근제한자] [제한자] 타입 변수명[=초기값]
	String company="좋은회사"; //제조사;
	int weight=100; //무게

	//constructor(생성자)
	//[접근제한자] [제한자] 클래스명(매개변수리스트){}
	
	//method-기능,동작
	//[접근제한자] [제한자] 리턴타입 메서드명(매개변수리스트){}

}
